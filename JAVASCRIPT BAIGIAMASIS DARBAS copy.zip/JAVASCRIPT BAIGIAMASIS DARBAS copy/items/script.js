const itemsContainer = document.getElementById("items-container");
const warningMessage = document.getElementById("warning-message");

const getItems = async () => {
  try {
    const response = await fetch(
      "https://66ed12b1380821644cdb372a.mockapi.io/items"
    );
    if (!response.ok) {
      throw new Error(`Error : ${response.statusText}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    warningMessage.innerText = error.message;
    console.error(error);
  }
};
const displayItems = (items) => {
  itemsContainer.innerHTML = "";
  items.forEach((item) => {
    const itemDiv = document.createElement("div");
    itemDiv.classList.add("item");

    const itemLink = document.createElement("a");
    itemLink.href = "index.html";
    itemLink.style.textDecoration = "none";
    itemLink.style.color = "inherit";

    const img = document.createElement("img");
    img.src = item.imageurl;
    img.alt = `Image of ${item.name}`;
    img.classList.add("item-image");

    const name = document.createElement("h3");
    name.innerText = item.name;

    const price = document.createElement("h4");
    price.innerText = `Price: $${item.price}`;

    const deleteButton = document.createElement("button");
    deleteButton.innerText = "Delete";
    deleteButton.addEventListener("click", (event) => {
      event.stopPropagation();
      itemDiv.remove();
    });

    itemLink.append(img);
    itemLink.append(name);
    itemLink.append(price);

    itemDiv.append(itemLink);
    itemDiv.append(deleteButton);

    itemsContainer.append(itemDiv);
  });
};
const initPage = async () => {
  const items = await getItems();
  if (items) {
    items.sort((a, b) => b.price - a.price);
    displayItems(items);
  }
};

initPage();
