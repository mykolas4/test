const nameInput = document.getElementById("name");
const priceInput = document.getElementById("price");
const locationInput = document.getElementById("location");
const descriptionInput = document.getElementById("description");
const imageurlInput = document.getElementById("imageurl");
const successMessage = document.createElement("h3");
successMessage.innerText = "You have added items successfully";
successMessage.setAttribute("class", "success");

const insertItems = async () => {
  const data = {
    name: nameInput.value.trim(),

    price: priceInput.value.trim(),
    location: locationInput.value.trim(),
    description: descriptionInput.value.trim(),
    imageurl: imageurlInput.value.trim(),
  };

  if (!data.name || !data.price || !data.location) {
    alert("Please fil all required fields.");
    return;
  }

  try {
    const response = await fetch(
      "https://66ed12b1380821644cdb372a.mockapi.io/items",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      }
    );

    if (response.ok) {
      document.body.append(successMessage);

      setTimeout(() => {
        window.location.replace("../items/index.html");
      }, 2000);
    } else {
      const errorData = await response.json();
      alert(`Error: ${errorData.message || "Failed to add item."}`);
    }
  } catch (error) {
    console.error("Error:", error);
    alert("An error while adding the item.");
  }
};

const btn = document.getElementById("add-btn");

btn.addEventListener("click", (event) => {
  event.preventDefault();
  insertItems();
});
